"""Classe para erros léxicos"""

class LexicalError(Exception):
    "To represent lexical errors"
